<?php
	if(isset($_POST['submit']))
	{
		$city=$_POST['city'];
		$apikey=$_POST['APPID'];
		$url = "http://api.openweathermap.org/data/2.5/weather?q=$city&APPID=$apikey";
		$json = file_get_contents($url);
		$json_data=json_decode($json);
		$json_new=(array)$json_data;
		$weather=(array)$json_new['weather'][0];
		$wind_speed=(array)$json_new['wind'];
		$temp=(array)$json_new['main'];
	}
?>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">

		<title>Weather Demo</title>

		<!-- Loading third party fonts -->
		<link href="http://fonts.googleapis.com/css?family=Roboto:300,400,700|" rel="stylesheet" type="text/css">
		<link href="fonts/font-awesome.min.css" rel="stylesheet" type="text/css">

		<!-- Loading main css file -->
		<link rel="stylesheet" href="style.css">

		<!--[if lt IE 9]>
		<script src="js/ie-support/html5.js"></script>
		<script src="js/ie-support/respond.js"></script>
		<![endif]-->

	</head>


	<body>

		<div class="site-content">
			<div class="site-header">
				<div class="container">
					<a href="index.html" class="branding">
						<img src="images/logo.png" alt="" class="logo">
						<div class="logo-type">
							<h1 class="site-title">Weather Check</h1>
							<small class="site-description">Live and Real Weather</small>
						</div>
					</a>

					<!-- Default snippet for navigation -->

				</div>
			</div> <!-- .site-header -->

			<div class="hero" data-bg-image="images/banner.png">
				<div class="container">
					<form action="" class="find-location" method="post">
						<input type="text" placeholder="Find your location..." name="city">
						<input type="hidden" name="APPID" value="55094bd5857766ceced752f2d77266b3" />
						<input type="submit" name="submit" value="Find">
					</form>

				</div>
			</div>
			<div class="forecast-table">
				<div class="container">
					<div class="forecast-container">
						<div class="today forecast">
							<div class="forecast-header">
								<div class="day"><?php echo date("l"); ?></div>
								<div class="date"><?php echo date("d M"); ?></div>
							</div> <!-- .forecast-header -->
							<div class="forecast-content">
								<div class="location"><?php if(isset($json_data)) print $json_new['name']; ?></div>
								<div class="degree">
									<div class="num" style="font-size:50"><?php if(isset($json_data)) print $temp['temp']-274; ?><sup>o</sup>C</div>
									<div class="forecast-icon">
									<?php
										if(isset($weather['main']))
											{
												if($weather['main']=="Clear")
												{
													echo "<img src='images/icons/icon-2.svg' alt='' width=90>";
												}
												elseif($weather['main']=="Clouds")
												{
													echo "<img src='images/icons/icon-3.svg' alt='' width=90>";
												}
												elseif($weather['main']=="Haze")
												{
													echo "<img src='images/icons/icon-8.svg' alt='' width=90>";
												}
												elseif($weather['main']=="Rain")
												{
													echo "<img src='images/icons/icon-9.svg' alt='' width=90>";
												}
												elseif($weather['main']=="Fog")
												{
													echo "<img src='images/icons/icon-7.svg' alt='' width=90>";
												}
												else
												{
													if(isset($weather['main']))
													{
														echo $weather['main'];
													}
												}
											}
									?>
									</div>
								</div>
								<span><img src="images/humidity.png" alt=""><?php if(isset($json_data)) print $temp['humidity'];?>%</span>
								<span><img src="images/icon-wind.png" alt=""><?php if(isset($json_data)) print $wind_speed['speed']; ?>km/h</span>
							</div>
						</div>
						<div class="forecast">
							<div class="forecast-header">
								<div class="day"><?php echo date('d M', strtotime(' +1 day'))?></div>
							</div> <!-- .forecast-header -->
							<div class="forecast-content">
								<div class="forecast-icon">
									<img src="images/icons/icon-3.svg" alt="" width=48>
								</div>
								<div class="degree">-<sup>o</sup>C</div>
								<small>-<sup>o</sup></small>
							</div>
						</div>
						<div class="forecast">
							<div class="forecast-header">
								<div class="day"><?php echo date('d M', strtotime(' +2 day'))?></div>
							</div> <!-- .forecast-header -->
							<div class="forecast-content">
								<div class="forecast-icon">
									<img src="images/icons/icon-5.svg" alt="" width=48>
								</div>
								<div class="degree">-<sup>o</sup>C</div>
								<small>-<sup>o</sup></small>
							</div>
						</div>
						<div class="forecast">
							<div class="forecast-header">
								<div class="day"><?php echo date('d M', strtotime(' +3 day'))?></div>
							</div> <!-- .forecast-header -->
							<div class="forecast-content">
								<div class="forecast-icon">
									<img src="images/icons/icon-7.svg" alt="" width=48>
								</div>
								<div class="degree">-<sup>o</sup>C</div>
								<small>-<sup>o</sup></small>
							</div>
						</div>
						<div class="forecast">
							<div class="forecast-header">
								<div class="day"><?php echo date('d M', strtotime(' +4 day'))?></div>
							</div> <!-- .forecast-header -->
							<div class="forecast-content">
								<div class="forecast-icon">
									<img src="images/icons/icon-12.svg" alt="" width=48>
								</div>
								<div class="degree">-<sup>o</sup>C</div>
								<small>-<sup>o</sup></small>
							</div>
						</div>
						<div class="forecast">
							<div class="forecast-header">
								<div class="day"><?php echo date('d M', strtotime(' +5 day'))?></div>
							</div> <!-- .forecast-header -->
							<div class="forecast-content">
								<div class="forecast-icon">
									<img src="images/icons/icon-13.svg" alt="" width=48>
								</div>
								<div class="degree">-<sup>o</sup>C</div>
								<small>-<sup>o</sup></small>
							</div>
						</div>
						<div class="forecast">
							<div class="forecast-header">
								<div class="day"><?php echo date('d M', strtotime(' +6 day'))?></div>
							</div> <!-- .forecast-header -->
							<div class="forecast-content">
								<div class="forecast-icon">
									<img src="images/icons/icon-14.svg" alt="" width=48>
								</div>
								<div class="degree">-<sup>o</sup>C</div>
								<small>-<sup>o</sup></small>
							</div>
						</div>
					</div>
				</div>
			</div>

			<footer class="site-footer">
				<div class="container">
					<p class="colophon">Copyright 2019 Virtual Web Developers. Designed by Themezy. All rights reserved</p>
				</div>
			</footer> <!-- .site-footer -->
		</div>

		<script src="js/jquery-1.11.1.min.js"></script>
		<script src="js/plugins.js"></script>
		<script src="js/app.js"></script>

	</body>

</html>
